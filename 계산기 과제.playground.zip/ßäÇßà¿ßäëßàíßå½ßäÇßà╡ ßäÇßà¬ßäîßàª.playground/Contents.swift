import Foundation
//String(format: "%.5f", ...) 같은 포맷 기능을 사용하려면 Foundation임포트가 필요


// MARK: - 추상 연산 프로토콜 정의dl
protocol AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double
}
//모든 연산 클래스가 따라야 할 기본 인터페이스입니다.
//Double 타입의 숫자를 2개 받아
//Double 결과를 반환하는 operate()메서드를 강제 구현하게 됩니다.

// MARK: - 연산 클래스들

class AddOperation: AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double {
        return a + b
    }
}
//AddOperation 덧셈

class SubtractOperation: AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double {
        return a - b
    }
}
//SubtractOperation 뺄셈

class MultiplyOperation: AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double {
        return a * b
    }
}
//MultiplyOperation 곱셈

class DivideOperation: AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double {
        return b != 0 ? a / b : 0.0
    }
}

//DivideOperation 나눗셈 (0으로 나눌 경우 0.0 반환 -> 안전 처리)

class ModuloOperation: AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double {
        return b != 0 ? a.truncatingRemainder(dividingBy: b) : 0.0
    }
}
//ModuloOperation 나머지 연산 (truncatingRemainder)

class RemainderOperation: AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double {
        return b != 0 ? a.remainder(dividingBy: b) : 0.0
    }
}
//RemainderOperation 부호 보존 나머지 (remainder)

// MARK: - Calculator 클래스

class Calculator {
    private var operation: AbstractOperation
//내부에 현재 사용할 연산 객체(operation)를 저장
//이 객체는 나중에 setOperation()으로 변경할 수 있다.
    init(operation: AbstractOperation) {
        self.operation = operation
    }

    func setOperation(_ operation: AbstractOperation) {
        self.operation = operation
    }
//실행 중에 연산 전력(더하기, 나누기 등)을 자유롭게 교체할 수 있다.
    
    func calculate(_ a: Double, _ b: Double) -> Double {
        return operation.operate(a, b)
    }
}
//실제 계산은 Calculator가 하지 않고, 내부의 operation 객체에게 위임한다.
// MARK: - 결과 출력 함수

func printResult(_ result: Double) {
    if result.truncatingRemainder(dividingBy: 1) == 0 {
        // 소수점 없는 값 → 정수로 출력
        print(Int(result))
    } else {
        // 소수점 있는 값 → 소수점 5자리까지 출력
        print(String(format: "%.5f", result))
    }
}
//Double 결과가 소수점 없이 딱 떨어지면 -> 정수로 출력
//소수점이 있으면 -> 소수점 5자리로 포맷팅해서 출력
// MARK: - 계산기 테스트

let calculator = Calculator(operation: AddOperation())
printResult(calculator.calculate(10, 5))  // 15

calculator.setOperation(SubtractOperation())
printResult(calculator.calculate(10, 5))

calculator.setOperation(MultiplyOperation())
printResult(calculator.calculate(10, 5))

calculator.setOperation(DivideOperation())
printResult(calculator.calculate(1, 3))

calculator.setOperation(ModuloOperation())
printResult(calculator.calculate(-13, 5))

calculator.setOperation(RemainderOperation())
printResult(calculator.calculate(-13, 5))

