//
//  main.swift
//  NumberBaseball
//
//  Created by 이태경 on 6/9/25.
//

import Foundation

print("Hello, World!")

let manager = BaseballGame()
manager.start()


