//
//  BaseballGame0.swift
//  NumberBaseball
//
//  Created by 이태경 on 6/9/25.
//

import Foundation
 //숫자 야구 게임을 담당하는 클래스
class BaseballGame {
    //프로그램 실행 상태를 나타냄
    var isRunning = true
    
    //게임 기록을 관리하는 객체
    let recordManager = RecordManager()
    
    //☎️메인 루프 함수 - 프로그램이 실행되는 동안 반복
    func start() {
        while isRunning {
            showMainMenu()
            
            //사용자 입력 받기 (옵셔널 처리)
            guard let input = readLine() else {
                print("입력을 다시 시도해주세요.")
                continue
            }
            
            //입력된 메뉴 번호에 따라 분기
            switch input {
            case "1":
                //게임 시작
                let trialCount = startGame()
                recordManager.add(trialCount: trialCount)
                
            case "2":
                //기록 보기
                recordManager.showRecords()
                
            case "3":
                //종료
                print("< 숫자 야구 게임을 종료합니다 >")
                isRunning = false
                
            default:
                //잘못된 메뉴 입력
                print("올바른 숫자를 입력해주세요!")
            }
        }
    }
    
    //🚚 메인 메뉴 출력 함수
    func showMainMenu() {
        print("\n환용합니다! 원하시는 번호를 입력해주세요")
        print("1. 게임 시작하기 2. 게임 기록 보기 3. 종료하기")
    }
    
    //🧐 게임 실행 함수: 정답 생성, 사용자 추측 반복
    func startGame() -> Int {
        print("\n< 게임을 시작합니다 >")
        
        //😃 게임 규칙 안내
        print("""
             [ 게임 규칙 안내 ]
             - 서로 다른 3자리 숫자를 맞추는 게임입니다.
             - 각 숫자는 0~9 사이이며, 중복되지 않습니다.
             - 첫 자리는 0이 될 수 없습니다.
             - 정답과 비교하여 다음과 같은 피드백이 주어집니다:
               🎯 스트라이크: 위치와 숫자가 일치
               🎲 볼: 숫자만 일치하지만 위치는 다름
               ❌ Nothing: 일치하는 숫자가 없음
             - 3스트라이크가 되면 게임이 종료됩니다.
             - 'quit'을 입력하면 게임이 중단됩니다.
             """)
        
        // 🎯 정답 생성
              let answer = makeAnswer()

              // 🐞 디버그 모드 (true로 설정 시 정답이 보임)
              let debugMode = false
              if debugMode {
                  print(" 📢 [Debug] 정답: \(answer.map(String.init).joined())")
              }

              var trialCount = 0 // 시도 횟수

              // 🔁 사용자 입력 루프
              while true {
                  print("\n숫자를 입력하세요 (예: 123), 또는 'quit' 입력:")
                  
                  guard let input = readLine()?.lowercased() else {
                      print("입력을 다시 시도해주세요.")
                      continue
                  }

                  // 종료 명령
                  if input == "quit" {
                      print("🚪 게임이 중단되었습니다.")
                      return trialCount
                  }

                  // 입력값 검증
                  guard isValidInput(input) else {
                      print("⚠️ 잘못된 입력입니다. 조건: 서로 다른 3자리 숫자, 첫 자리는 0 불가. 예: 123")
                      continue
                  }

                  trialCount += 1
                  
                  // 입력 문자열 → 정수 배열 변환 (예: "123" → [1, 2, 3])
                  let guess = input.compactMap { Int(String($0)) }

                  // 스트라이크/볼 판정
                  let result = compare(answer: answer, guess: guess)

                  // 결과 출력
                  if result.strike == 3 {
                      print("🎉 정답입니다! \(trialCount)번 만에 맞추셨습니다.")
                      break
                  } else if result.strike == 0 && result.ball == 0 {
                      print("❌ Nothing")
                  } else {
                      print("🎯 \(result.strike)스트라이크  🎲 \(result.ball)볼")
                  }
              }

              return trialCount
          }

          // 🎲 정답 생성 함수 - 0~9 중 중복 없는 숫자 3개, 첫 숫자는 0이 아님
          func makeAnswer() -> [Int] {
              var digits: [Int]
              repeat {
                  digits = Array(0...9).shuffled()
              } while digits[0] == 0
              
              return Array(digits.prefix(3))
          }

          // ✔️ 입력 검증 함수
          func isValidInput(_ input: String) -> Bool {
              // 길이 3, 모두 숫자 확인
              if input.count != 3 || input.contains(where: { !$0.isNumber }) {
                  return false
              }

              // 정수 배열로 변환
              let digits = input.compactMap { Int(String($0)) }

              // 중복 없음 + 첫 자리가 0이 아닌지 확인
              return Set(digits).count == 3 && digits[0] != 0
          }

          // ⚖️ 정답과 사용자 입력 비교 함수
          func compare(answer: [Int], guess: [Int]) -> (strike: Int, ball: Int) {
              var strike = 0
              var ball = 0
              
              for (i, num) in guess.enumerated() {
                  if answer[i] == num {
                      strike += 1
                  } else if answer.contains(num) {
                      ball += 1
                  }
              }
              
              return (strike, ball)
          }
      }



