//
//  Untitled.swift
//  NumberBaseball
//
//  Created by 이태경 on 6/9/25.
//

// 📊 게임 기록 저장 클래스
class RecordManager {
    private var records: [Int] = []
    
    // 기록 추가 함수
    func add(trialCount: Int) {
        records.append(trialCount)
    }
    
    // 기록 출력 함수
    func showRecords() {
        print("\n< 게임 기록 보기 >")
        
        if records.isEmpty {
            print("아직 완료한 게임이 없습니다.")
            return
        }

        for (index, count) in records.enumerated() {
            print("\(index + 1)번째 게임 : 시도 횟수 - \(count)")
        }
    }
}
